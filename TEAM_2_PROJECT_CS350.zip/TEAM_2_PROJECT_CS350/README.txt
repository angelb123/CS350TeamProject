Team 2 project
CS 350 Spring 2021
Dr. Tappan

Team Members: 

Angel Bermudez
Dustin Lawton
Han Zhang

Included files in this zip: 

CommandInterpreter.java
CreateInterpreter.java
DefineInterpreter.java
DeleteInterpreter.java
ProgramInterpreter.java
SetInterpreter.java

Github repository: https://github.com/angelb123/CS350TeamProject
